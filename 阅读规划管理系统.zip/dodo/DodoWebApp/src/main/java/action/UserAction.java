package action;

import Entity.User;
import base.Connection;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;
import service.Service;
import util.SpringIocUtil;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.xml.ws.http.HTTPException;
import java.util.Map;

/**
 * Created by fan on 7/1/2016.
 */
public class UserAction extends ActionSupport {

    public String addUser() {
        HttpServletRequest request = ServletActionContext.getRequest();
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        HttpSession session = request.getSession();
        Connection conn = (Connection) session.getAttribute("connection");

        User user = new User();
        user.setEmail(email);
        user.setPassword(password);
        user.setFirstName(firstName);
        user.setLastName(lastName);

        Service service = SpringIocUtil.getBean("linkedService");
        service.setConn(conn);
        try {
            user = service.user().create(user).request();
        } catch (HTTPException e) {
            e.printStackTrace();
            if (e.getStatusCode()==401) return LOGIN;
            else return ERROR;
        }


        return SUCCESS;
    }
}
