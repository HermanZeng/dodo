package test;

/**
 * Created by fan on 7/1/2016.
 */
public interface MessageStore {
    String getMessage();
}
