package service.resource;

import Entity.User;
import base.Connection;
import base.DodoApiRequest;
import org.springframework.http.HttpMethod;

/**
 * Created by fan on 7/1/2016.
 */
public class UsersResource {
    private Connection connection;
    private String url;

    public UsersResource(String url, Connection connection) {
        this.url = url;
        this.connection = connection;
    }

    public Create create(User user){
        return new Create(user);
    }

    public Show show(String userId){
        return new Show(userId);
    }

    public Update update(String userId, User user){
        return new Update(userId, user);
    }

    public Delete delete(String userId){
        return new Delete(userId);
    }


    public class Create extends DodoApiRequest<User,User>{
        public Create(User user){
            super(connection,url, HttpMethod.POST,"",user,User.class);
        }
    }

    public class Show extends DodoApiRequest<Void, User>{
        public Show(String userId) {
            super(connection, url, HttpMethod.GET, new StringBuilder("/").append(userId).toString(), null, User.class);
        }
    }

    public class Update extends DodoApiRequest<User,User>{
        public Update(String userId, User user) {
            super(connection, url, HttpMethod.PUT, new StringBuilder("/").append(userId).toString(), user, User.class);
        }
    }

    public class Delete extends DodoApiRequest<Void, Void>{
        public Delete(String userId){
            super(connection,url,HttpMethod.DELETE,new StringBuilder("/").append(userId).toString(), null, Void.class);
        }
    }
}
