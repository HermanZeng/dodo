package service;

import base.Connection;
import service.resource.AuthResource;
import service.resource.UsersResource;

/**
 * Created by fan on 7/1/2016.
 */
public class Service {
    // TODO: IOC
    private String apiUrl;
    private Connection conn=null;

    public Service(String apiUrl) {
        this.apiUrl = apiUrl;
        this.conn = null;
    }

    public String getApiUrl() {
        return apiUrl;
    }

    public void setApiUrl(String apiUrl) {
        this.apiUrl = apiUrl;
    }

    public Connection getConn() {
        return conn;
    }

    public void setConn(Connection conn) {
        this.conn = conn;
    }

    public AuthResource auth() {
        return new AuthResource(apiUrl + "/auth", conn);
    }

    public UsersResource user() {
        return new UsersResource(apiUrl + "/user", conn);
    }
}
