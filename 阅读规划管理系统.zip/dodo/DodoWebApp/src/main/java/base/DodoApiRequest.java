package base;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

/**
 * Created by fan on 7/1/2016.
 */
public class DodoApiRequest<T, R> {
    private String url;
    private HttpMethod method;
    private HttpHeaders header;
    private T jsonBody;
    private Class<R> returnType;
    private ResponseEntity<R> response;
    private RestTemplate restTemplate;
    private Connection connection;

    public DodoApiRequest(Connection conn, String url, HttpMethod method, String path, T jsonBody, Class<R> returnType) {
        this.connection = conn;
        this.url = url + path;
        this.method = method;
        this.header = new HttpHeaders();
        this.jsonBody = jsonBody;
        this.returnType = returnType;
        this.restTemplate = new RestTemplate();

        this.response = null;

        if (connection != null && header.isEmpty()) {
            header.set("X-Auth-Token", conn.getToken());
        }
//        String token = tokenProvider.getToken();
//        if (header.isEmpty()) {
//            if (!token.equals("")) {
//                header.set("X-Auth-Token", token);
//            }
//        }

    }

    public R request() {
        System.out.println("*****request*****");
        System.out.println("url: " + url);
        System.out.println("method: " + method.name());
        if (jsonBody == null) {
            System.out.println("body: null");
        } else {
            System.out.println("body: " + jsonBody.toString());
        }
        if (connection == null) {
            System.out.println("connection: null");
        } else {
            System.out.println("connection: " + connection);
        }
        if (header.get("X-Auth-Token") == null) {
            System.out.println("header: null");
        } else {
            System.out.println("header: " + (header.get("X-Auth-Token")).toString());

        }
        HttpEntity<?> entity = new HttpEntity<Object>(jsonBody, header);
        response = restTemplate.exchange(url, method, entity, returnType);

        return response.getBody();
    }
}
