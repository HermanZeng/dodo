package util;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.io.StringWriter;

/**
 * Created by fan on 7/1/2016.
 */
public final class JsonUtil {
    private static final ObjectMapper mapper = new ObjectMapper();

    public static String objectToJson(Object object) {
        String ret = "";
        try {
            StringWriter result = new StringWriter();
            mapper.writeValue(result, object);
            ret = result.toString();
        } catch (JsonGenerationException e) {
            e.printStackTrace();
        } catch (JsonMappingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return ret;
    }

}
